import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IChatBotApplicationCustomizerProperties {
    testMessage: string;
}
/** A Custom Action which can be run during execution of a Client Side Application */
export default class ChatBotApplicationCustomizer extends BaseApplicationCustomizer<IChatBotApplicationCustomizerProperties> {
    private _bottomPlaceholder;
    private addWindowStateChangeObserver;
    private checkInactivityTimeout;
    private initializeSessionStorage;
    /**
     * Shows the initial message immediately if on a larger screen (non-mobile).
     */
    private initializeChatView;
    private refreshInactivityTimeout;
    private responseReceivedHandler;
    /**
     * Scrolls to either the last user message in the list or the first one after it,
     * which will be the first new response message.
     */
    private scrollToMessage;
    private applyCustomStyles;
    private addCustomFooter;
    /**
     * Enters a value into the input box and submits it, as though a user was entering it.
     */
    private submitUserQuery;
    /**
     * Loads inactivity messages from the hidden page elements.
     */
    private populateInactivityMessages;
    private populateMessages;
    /**
     * Renders a custom Message.  Message formats supported are JSON and text/html.
     */
    private renderCustomMessage;
    /**
     * Applies any post processing to messages.
     */
    private processBotMessages;
    /**
     * Applies HTML formatting to each Text message
     */
    private processTextResponses;
    /**
     * Applies any custom formatting to JSON message types (chips, etc).
     * Since chip messages are generated and contained in a shadow root, we have to inject the styles at runtime.
     */
    private processRichContentResponses;
    private processMessageHtml;
    /**
     * Updates the title bar, including adding a close button
     * to the top right corner of the chat window.
     */
    private updateTitleBar;
    private closeChatWindow;
    /**
     * Perform updates related to changing window state.
     *
     * NOTE: This function may be called more than once per window state change.
     */
    private updateWindowState;
    private activateChatSession;
    private coverElement;
    private deactivateChatSession;
    private enableInputElement;
    private ensureChatInitialized;
    private ensureInitialMessagesPopulated;
    /**
     * Returns the state of the chat window.  It may be in one of three states:
     *   WINDOW_STATE_MINIMAL - Used as the default state where it only shows a single welcome message
     *   WINDOW_STATE_OPEN - The User has expanded the window and it shows the full message list and input field
     *   WINDOW_STATE_CLOSED - The user has closed the window, so only the chat icon remains
     */
    private getChatWindowState;
    private getChatWrapperElement;
    private getCloseButtonElement;
    private getDFMessengerElement;
    private getMessengerChatElement;
    private getMessengerWrapperDivElement;
    private getMessageListElement;
    /**
     * Returns the message list element.
     */
    private getMessageListDivElement;
    private getChatSessionId;
    private getTitleWrapperElement;
    /**
     * Returns the input text box element.
     */
    private getInputFieldElement;
    private getUserInputElement;
    private isChatSessionActive;
    private updateChatWindowStyle;
    private updateInputFieldState;
    private _onDispose;
    private _renderPlaceHolders;
    onInit(): Promise<void>;
}
//# sourceMappingURL=ChatBotApplicationCustomizer.d.ts.map