define([], function() {
  return {
    "Title": "ChatBotApplicationCustomizer"
  }
});