declare interface IChatBotApplicationCustomizerStrings {
  Title: string;
}

declare module 'ChatBotApplicationCustomizerStrings' {
  const strings: IChatBotApplicationCustomizerStrings;
  export = strings;
}
