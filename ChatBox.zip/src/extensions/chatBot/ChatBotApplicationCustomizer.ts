import { Log } from '@microsoft/sp-core-library';
import {
  BaseApplicationCustomizer, PlaceholderContent, PlaceholderName
} from '@microsoft/sp-application-base';

//import { escape } from '@microsoft/sp-lodash-subset';
// import styles from './AppCustomizer.module.scss';
import * as strings from 'ChatBotApplicationCustomizerStrings';

const LOG_SOURCE: string = 'ChatBotApplicationCustomizer';
//const TOOLTIP_OPEN_CHAT = 'Open Chat';
const TOOLTIP_CLOSE_CHAT = 'Close Chat';
const HOVER_COLOR_DARK = '#121212';

const CHATBOT_FONT_FAMILY = "'Sans', 'Noto Sans', Arial, 'sans serif'";

// Breakpoint where DF Messenger switches between mobile/non-mobile styles (pixels)
const NON_MOBILE_MIN_HEIGHT = 541;
const NON_MOBILE_MIN_WIDTH = 501;

const PRIVACY_POLICY_URL = 'https://www.interiorhealth.ca/about-ih/our-website/privacy-terms';

const WINDOW_STATE_CLOSED = 'CLOSED';
const WINDOW_STATE_MINIMAL = 'MINIMAL';
const WINDOW_STATE_OPEN = 'OPEN';
//const WINDOW_STATE_VAR_NAME = 'chatWindowState';
//const WINDOW_INITIAL_STATE_WELCOME = 'on-welcome';

const CHAT_INITIAL_MESSAGES_POPULATED_VAR_NAME = 'chatInitialMessagesPopulated';
const CHAT_INITIAL_QUERY_TEXT = "Let's Get Started";
const CHAT_SESSION_ACTIVE_VAR_NAME = 'chatSessionActive';
const CHAT_SESSION_ID_VAR_NAME = 'chatSessionID';
const CHAT_SESSION_INITIALIZED_VAR_NAME = 'chatSessionInitialized';
const CHAT_WINDOW_STATE_VAR_NAME = 'chatWindowState';

const INACTIVITY_TIMEOUT_INTERVAL_MS = 5000;
const INACTIVITY_TIMEOUT_MS = 1770000;
const INACTIVITY_TIMESTAMP_VAR_NAME = 'chatInactivityTimestamp';

const TRUE_VALUE = 'true';
const FALSE_VALUE = 'false';

const Z_INDEX = 2000;
/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IChatBotApplicationCustomizerProperties {
  // This is an example; replace with your own property
  testMessage: string;
}

/** A Custom Action which can be run during execution of a Client Side Application */
export default class ChatBotApplicationCustomizer
  extends BaseApplicationCustomizer<IChatBotApplicationCustomizerProperties> {

  private _bottomPlaceholder: PlaceholderContent | undefined;
  //private _bottomPlaceholder: PlaceholderContent | undefined;

  private addWindowStateChangeObserver() {
    const scope = this;
    let observer = new MutationObserver(function (mutations) {
      setTimeout(() => {
        scope.updateWindowState();
      }, 1);
    });

    observer.observe(this.getChatWrapperElement(), { attributes: true });
  }

  private checkInactivityTimeout() {
    let inactivityTimestamp = sessionStorage.getItem(INACTIVITY_TIMESTAMP_VAR_NAME);
    if (inactivityTimestamp) {
      let elapsedTimeMs = new Date().getTime() - parseInt(inactivityTimestamp);
      if (elapsedTimeMs >= INACTIVITY_TIMEOUT_MS) {
        this.deactivateChatSession();
      }
    }
  }

  private initializeSessionStorage() {
    [
      CHAT_INITIAL_MESSAGES_POPULATED_VAR_NAME,
      CHAT_SESSION_ACTIVE_VAR_NAME,
      CHAT_SESSION_ID_VAR_NAME,
      CHAT_SESSION_INITIALIZED_VAR_NAME,
      CHAT_WINDOW_STATE_VAR_NAME,
      INACTIVITY_TIMESTAMP_VAR_NAME
    ].forEach((keyName) => sessionStorage.removeItem(keyName));
  }

  /**
   * Shows the initial message immediately if on a larger screen (non-mobile).
   */
  private initializeChatView() {
    if (document.documentElement.clientWidth >= NON_MOBILE_MIN_WIDTH) {
      const df = this.getDFMessengerElement() as any;

      df.showMinChat();
    }
  }

  private refreshInactivityTimeout() {
    sessionStorage.setItem(INACTIVITY_TIMESTAMP_VAR_NAME, new Date().getTime().toString());
  }

  // A response has been received from Dialogflow.  Handle the new messages.
  private responseReceivedHandler(event: any) {
    this.refreshInactivityTimeout();

    const result = event.detail.response.queryResult;

    // If there are any entries in the parameters object it is prompting the user for a response
    if (result.parameters && Object.keys(result.parameters).length > 0 && !result.allRequiredParamsPresent) {
      this.getInputFieldElement().setAttribute('placeholder', 'Enter response...');
    } else {
      this.getInputFieldElement().setAttribute('placeholder', 'Ask something...');
    }

    this.activateChatSession();

    // Wait until the messages are available, and allow a bit of time for the initial scrolling.
    setTimeout(() => {
      // Process bot responses and render HTML.
      this.processBotMessages();

      // Scroll to the beginning of the new messages
      this.scrollToMessage(false, false, true);
    }, 150);
  }

  /**
   * Scrolls to either the last user message in the list or the first one after it,
   * which will be the first new response message.
   */
  private scrollToMessage(toUserMessage: any, toLastMessage = false, smooth = false) {
    // Find the message to scroll to.
    var message;
    const messages = this.getMessageListDivElement().querySelectorAll('div.message');
    if (!toLastMessage) {
      for (var i = 0; i < messages.length; i++) {
        if (messages[i].classList.contains('user-message')) {
          if (toUserMessage) {
            message = messages[i];
          } else if (messages.length >= i) {
            message = messages[i + 1];
          }
        }
      }
    } else if (messages.length > 0) {
      message = messages[messages.length - 1];
    }

    // Scroll to the desired message.
    if (message) {
      const scrollIntoViewOptions = { block: 'start', inline: 'nearest', behavior: undefined };

      if (smooth) {
        scrollIntoViewOptions.behavior = 'smooth';
      }
      message.scrollIntoView(scrollIntoViewOptions);
    }
  }

  private applyCustomStyles() {
    const style = document.createElement('style');
    style.textContent = `@media screen and (min-width: ${NON_MOBILE_MIN_WIDTH}px) { div.chat-wrapper { max-height: 70% } } `;
    this.getChatWrapperElement().appendChild(style);
    //this.getMessengerWrapperDivElement().style.zIndex = Z_INDEX;

    this.getMessengerWrapperDivElement().setAttribute('style', 'zIndex:' + Z_INDEX);

  }

  private addCustomFooter() {
    const dfMessengerChat = this.getMessengerChatElement();
    const divChatWrapper = this.getChatWrapperElement();

    const style = document.createElement('style');

    // Footer style and footer button behavior styles
    style.textContent =
      'div.chat-min #chatbotFooter { display: none } ' +
      '#chatbotFooter a { color: white } #chatbotFooter a:hover { color: lightblue } #chatbotFooter a:focus { color: lightGrey } #chatbotFooter a { font-family: ' +
      CHATBOT_FONT_FAMILY +
      ' } ' +
      '#chatbotFooter button { color: white } #chatbotFooter button:hover { color: lightGrey } #chatbotFooter button:focus { color: lightGrey } #chatbotFooter button { font-family: ' +
      CHATBOT_FONT_FAMILY +
      ' } ';

    dfMessengerChat.shadowRoot.appendChild(style);

    const customFooterDiv = document.createElement('div') as HTMLElement;
    customFooterDiv.setAttribute('id', 'chatbotFooter');
    customFooterDiv.setAttribute('style',
      'padding-top: 5px; padding-left: 10px; padding-right: 10px; padding-bottom: 5px; vertical-align: middle; background: #005AA2');
    divChatWrapper.appendChild(customFooterDiv);

    // Style the footer items so they look like hyperlinks.
    const footerItemStyle =
      'padding: 0px; padding-top: 2px; background: none!important; border: none; ' +
      'text-decoration: underline; cursor: pointer; line-height: 1.5em;';

    // Add a privacy policy link.
    const link = document.createElement('a');
    link.innerText = 'Privacy Policy';
    link.setAttribute('href', PRIVACY_POLICY_URL);
    link.setAttribute('target', '_blank');
    link.setAttribute('style', footerItemStyle + ' float: right;');
    customFooterDiv.appendChild(link);
  }

  /**
   * Enters a value into the input box and submits it, as though a user was entering it.
   */
  private submitUserQuery(queryText: string) {
    const userInput = this.getUserInputElement() as HTMLElement;
    let sendElement = userInput.shadowRoot.querySelector('#sendIconButton');
    if (!sendElement) {
      sendElement = userInput.shadowRoot.querySelector('#sendIcon');
    }

    const inputBox = this.getInputFieldElement() as HTMLInputElement;;
    inputBox.value = queryText;

    const event = new Event('click');
    sendElement.dispatchEvent(event);
    inputBox.blur();

    // Scroll to the newly entered user message
    this.scrollToMessage(true);
  }

  /**
   * Loads inactivity messages from the hidden page elements.
   */
  private populateInactivityMessages() {
    this.populateMessages(document.querySelector('#chatbot-inactivity-messages'));
  }

  private populateMessages(messageContainerElement: any) {
    if (messageContainerElement) {
      for (let messageElement of messageContainerElement.querySelectorAll('p')) {
        const messageHtml = messageElement.innerHTML;
        if (messageHtml.length > 0) {
          this.renderCustomMessage(messageHtml);
          setTimeout(() => {
            this.processBotMessages();
          }, 1);
        }
      }
    }
  }

  /**
   * Renders a custom Message.  Message formats supported are JSON and text/html.
   */
  private renderCustomMessage(message: any) {
    if (message.length > 0) {
      const dfMessenger = this.getDFMessengerElement() as any;
      if (message.trim().startsWith('{')) {
        const jsonMessage = JSON.parse('[' + message + ']');
        dfMessenger.renderCustomCard(jsonMessage);
      } else {
        dfMessenger.renderCustomText(message);
      }
    }
  }

  /**
   * Applies any post processing to messages.
   */
  private processBotMessages() {
    let chatWindowState = this.getChatWindowState();

    if (chatWindowState === WINDOW_STATE_OPEN || chatWindowState === WINDOW_STATE_MINIMAL) {
      this.processTextResponses();
      this.processRichContentResponses();
    }
  }

  /**
   * Applies HTML formatting to each Text message
   */
  private processTextResponses() {
    const botMessages = this.getMessageListDivElement().querySelectorAll('.bot-message');

    botMessages.forEach((message) => {
      this.processMessageHtml(message);
    });
  }

  /**
   * Applies any custom formatting to JSON message types (chips, etc).
   * Since chip messages are generated and contained in a shadow root, we have to inject the styles at runtime.
   */
  private processRichContentResponses() {
    // Add a style for Chips so that when they line wrap it still looks good with spacing (VA-117)
    const chipsLineStyle = document.createElement('style');

    chipsLineStyle.textContent =
      '.df-chips-wrapper a, .df-chips-wrapper span.chip ' +
      `{ line-height: normal; padding: 0 10px; background: #005AA2; color: white; font-family: ${CHATBOT_FONT_FAMILY} } `;

    // Override the chip button style to inherit values from the parent element.
    chipsLineStyle.textContent +=
      '.df-chips-wrapper span.chip button ' +
      `{ line-height: inherit; padding: inherit; background: inherit; color: inherit; font-family: inherit } `;

    // Apply the same style as mouse hover when a chip is tabbed into
    chipsLineStyle.textContent +=
      '.df-chips-wrapper a:focus, .df-chips-wrapper a:hover, ' +
      '.df-chips-wrapper span.chip:focus-within, .df-chips-wrapper span.chip:hover ' +
      '{ background: hsl(0,0%,90%); color: #005AA2 }';

    const dfChips = this.getMessageListDivElement().querySelectorAll('df-chips');
    let chipCount = 0;

    dfChips.forEach(function (aChip) {
      aChip.shadowRoot.appendChild(chipsLineStyle);
      chipCount++;
      let lastChip = chipCount == dfChips.length;
      if (!lastChip) {
        let dfChipsWrapper = aChip.shadowRoot.querySelector('.df-chips-wrapper');
        if (dfChipsWrapper) {

          let active = false
          //this.isChatSessionActive();

          setTimeout(() => {
            let active = this.isChatSessionActive();
            dfChipsWrapper.querySelectorAll('button').forEach(function (button) {
              this.enableInputElement(button, active);
            });
            this.coverElement(dfChipsWrapper, !active);
          }, 1);
        }
      }
    });
  }

  private processMessageHtml(element: any) {
    // If element hasn't previously been processed, override the innerHTML with the innerText value
    // to render any HTML formatting.
    const className = 'chat-message-processed';
    if (!element.classList.contains(className)) {
      let textContent = element.textContent;
      if (textContent != null) {
        textContent = textContent.replace(/^\s*agent\s*says\s*:?\s*/i, '');
      }
      element.innerHTML = textContent;
      element.classList.add(className);
    }
  }

  /**
   * Updates the title bar, including adding a close button
   * to the top right corner of the chat window.
   */
  private updateTitleBar() {
    const dfMessenger = this.getDFMessengerElement();
    const titleWrapper = this.getTitleWrapperElement();

    // clone the existing close icon which is part of df-messenger
    const closeIconClone = dfMessenger.shadowRoot.querySelector('#closeSvg').cloneNode(true);

    // create a new button to encapsulate the icon
    const closeButton = document.createElement('button');
    closeButton.id = 'closeButton';
    closeButton.title = TOOLTIP_CLOSE_CHAT;
    closeButton.onclick = () => {
      this.closeChatWindow();
    };
    closeButton.setAttribute('tabindex', '0');

    closeButton.appendChild(closeIconClone);

    const closeButtonStyle = document.createElement('style');
    closeButtonStyle.textContent =
      '#closeButton { height:100%; border:none; fill:var(--df-messenger-button-titlebar-font-color); background-color:transparent; cursor:pointer } #closeButton:hover { fill:' +
      HOVER_COLOR_DARK +
      ' } #closeButton:focus { fill:' +
      HOVER_COLOR_DARK +
      ' } ' +
      '#minimizeIcon, #minimizeIconButton {display: none} ' +
      'div.title-wrapper, div.title-wrapper h2 {font-size: 17px} ';

    titleWrapper.appendChild(closeButton);
    titleWrapper.appendChild(closeButtonStyle);
  }

  private closeChatWindow() {
    const dfMessenger = this.getDFMessengerElement();
    const chatbotIcon = dfMessenger.shadowRoot.querySelector('#widgetIcon') as HTMLButtonElement;
    chatbotIcon.click();
  }

  /**
   * Perform updates related to changing window state.
   *
   * NOTE: This function may be called more than once per window state change.
   */
  private updateWindowState() {
    let windowState = this.getChatWindowState();
    let savedWindowState = sessionStorage.getItem(CHAT_WINDOW_STATE_VAR_NAME);
    let windowStateChanged = savedWindowState !== windowState;

    if (windowStateChanged) {
      sessionStorage.setItem(CHAT_WINDOW_STATE_VAR_NAME, windowState);
    }
    switch (windowState) {
      case WINDOW_STATE_OPEN:
        this.updateChatWindowStyle();
        this.updateInputFieldState();
        if (!this.getCloseButtonElement()) {
          this.updateTitleBar();
        }
        this.ensureInitialMessagesPopulated();
        this.ensureChatInitialized();
        if (windowStateChanged) {
          setTimeout(() => {
            this.processBotMessages();

            if (this.isChatSessionActive()) {
              this.scrollToMessage(false);
            } else {
              this.scrollToMessage(false, true);
            }
          }, 1);
        }
        break;

      case WINDOW_STATE_MINIMAL:
        this.ensureInitialMessagesPopulated();
        break;

      case WINDOW_STATE_CLOSED:
        break;

      default:
        throw `Invalid window state (${windowState}).`;
    }
  }

  private activateChatSession() {
    if (!this.isChatSessionActive()) {
      sessionStorage.setItem(CHAT_SESSION_ACTIVE_VAR_NAME, TRUE_VALUE);
      this.updateInputFieldState();
    }
  }

  private coverElement(element: any, cover = true, backgroundColor = 'var(--df-messenger-chat-background-color)') {
    if (element) {
      let className = 'cover-overlay';
      let coverElement = element.querySelector(`:scope > div.${className}`);
      if (cover) {
        if (!coverElement) {
          coverElement = document.createElement('div');
          coverElement.classList.add(className);
          coverElement.style.cssText =
            'position: absolute; top: 0; left: 0; width: 100%; height: 100%; ' +
            `background-color: ${backgroundColor}; opacity: 0.5;`;
          element.style.position = 'relative';
          element.appendChild(coverElement);
        }
      } else {
        if (coverElement) {
          element.removeChild(coverElement);
        }
      }
    }
  }

  private deactivateChatSession() {
    if (this.isChatSessionActive()) {
      sessionStorage.setItem(CHAT_SESSION_ACTIVE_VAR_NAME, FALSE_VALUE);
      this.updateInputFieldState();
      this.populateInactivityMessages();
    }
  }

  private enableInputElement(element: any, enable = true) {
    if (element) {
      if (enable) {
        element.removeAttribute('disabled');
      } else {
        element.setAttribute('disabled', '');
      }
    }
  }

  private ensureChatInitialized() {
    let savedChatSessionId = sessionStorage.getItem(CHAT_SESSION_ID_VAR_NAME);
    let chatSessionId = this.getChatSessionId();

    if (chatSessionId != savedChatSessionId) {
      sessionStorage.setItem(CHAT_SESSION_INITIALIZED_VAR_NAME, '');
      sessionStorage.setItem(CHAT_SESSION_ID_VAR_NAME, chatSessionId);
    }

    let chatSessionInitialized = sessionStorage.getItem(CHAT_SESSION_INITIALIZED_VAR_NAME) === TRUE_VALUE;

    if (!chatSessionInitialized) {
      this.submitUserQuery(CHAT_INITIAL_QUERY_TEXT);
      sessionStorage.setItem(CHAT_SESSION_INITIALIZED_VAR_NAME, TRUE_VALUE);
    }
  }

  private ensureInitialMessagesPopulated() {
    let chatInitialMessagesPopulated = sessionStorage.getItem(CHAT_INITIAL_MESSAGES_POPULATED_VAR_NAME) === TRUE_VALUE;

    if (!chatInitialMessagesPopulated) {
      this.populateMessages(document.querySelector('#chatbot-initial-messages'));
      sessionStorage.setItem(CHAT_INITIAL_MESSAGES_POPULATED_VAR_NAME, TRUE_VALUE);
    }
  }

  /**
   * Returns the state of the chat window.  It may be in one of three states:
   *   WINDOW_STATE_MINIMAL - Used as the default state where it only shows a single welcome message
   *   WINDOW_STATE_OPEN - The User has expanded the window and it shows the full message list and input field
   *   WINDOW_STATE_CLOSED - The user has closed the window, so only the chat icon remains
   */
  private getChatWindowState() {
    let windowState;

    if (this.getChatWrapperElement().classList.contains('chat-min')) {
      windowState = WINDOW_STATE_MINIMAL;
    } else {
      windowState = this.getDFMessengerElement().hasAttribute('expand') ? WINDOW_STATE_OPEN : WINDOW_STATE_CLOSED;
    }
    return windowState;
  }

  private getChatWrapperElement() {
    return this.getMessengerChatElement().shadowRoot.querySelector('div.chat-wrapper');
  }

  private getCloseButtonElement() {
    return this.getTitleWrapperElement().querySelector('#closeButton');
  }

  private getDFMessengerElement() {
    return this._bottomPlaceholder.domElement.querySelector('df-messenger');
  }

  private getMessengerChatElement() {
    return this.getDFMessengerElement().shadowRoot.querySelector('df-messenger-chat');
  }

  private getMessengerWrapperDivElement() {
    return this.getDFMessengerElement().shadowRoot.querySelector('div.df-messenger-wrapper');
  }

  private getMessageListElement() {
    return this.getMessengerChatElement().shadowRoot.querySelector('df-message-list');
  }

  /**
   * Returns the message list element.
   */
  private getMessageListDivElement() {
    return this.getMessageListElement().shadowRoot.querySelector('div.message-list-wrapper div#messageList');
  }

  private getChatSessionId() {
    let chatSessionId = this.getDFMessengerElement().getAttribute('session-id');
    if (!chatSessionId) {
      throw 'Failed to retrieve chat session ID.';
    }
    return chatSessionId;
  }

  private getTitleWrapperElement() {
    return this.getMessengerChatElement()
      .shadowRoot.querySelector('df-messenger-titlebar')
      .shadowRoot.querySelector('div.title-wrapper');
  }

  /**
   * Returns the input text box element.
   */
  private getInputFieldElement() {
    return this.getUserInputElement().shadowRoot.querySelector('input[type="text"]');
  }

  private getUserInputElement() {
    return this.getMessengerChatElement().shadowRoot.querySelector('df-messenger-user-input');
  }

  private isChatSessionActive() {
    return sessionStorage.getItem(CHAT_SESSION_ACTIVE_VAR_NAME) === TRUE_VALUE;
  }

  private updateChatWindowStyle() {
    const chatWrapper = this.getChatWrapperElement() as HTMLElement;

    if (
      document.documentElement.clientWidth >= NON_MOBILE_MIN_WIDTH &&
      document.documentElement.clientHeight < NON_MOBILE_MIN_HEIGHT &&
      document.documentElement.clientWidth >= document.documentElement.clientHeight &&
      this.getChatWindowState() === WINDOW_STATE_OPEN
    ) {
      chatWrapper.style.height = '100%';
      chatWrapper.style.maxHeight = '100%';
      chatWrapper.style.right = '100px';
      chatWrapper.style.top = '0px';

      //chatWrapper.setAttribute('style', 'height: 100%; maxHeight: 100%; right: 100px; top:0px');

    } else {
      chatWrapper.style.removeProperty('height');
      chatWrapper.style.removeProperty('max-height');
      chatWrapper.style.removeProperty('right');
      chatWrapper.style.removeProperty('top');
    }
  }

  private updateInputFieldState() {
    if (this.getChatWindowState() === WINDOW_STATE_OPEN) {
      let inputWrapper = this.getUserInputElement().shadowRoot.querySelector('.input-box-wrapper');
      let active = this.isChatSessionActive();
      if (inputWrapper) {
        let inputField = this.getInputFieldElement();
        let sendButton = inputWrapper.querySelector('button#sendIconButton');
        this.enableInputElement(inputField, active);
        this.enableInputElement(sendButton, active);
      }
      this.coverElement(inputWrapper, !active, '#BBB');
    }
  }

  private _onDispose(): void {
    console.log('_onDispose called');
  }

  private _renderPlaceHolders(): void {
    // Handling the bottom placeholder
    if (!this._bottomPlaceholder) {
      this._bottomPlaceholder = this.context.placeholderProvider.tryCreateContent(
        PlaceholderName.Bottom,
        { onDispose: this._onDispose }
      );
    }

    // The extension should not assume that the expected placeholder is available.
    if (!this._bottomPlaceholder) {
      console.error("The expected placeholder (Bottom) was not found.");
      return;
    }

    if (this._bottomPlaceholder.domElement) {
      var div = document.createElement("div");

      div.innerHTML = `
        <style>
          df-messenger {
            --df-messenger-bot-message: #FFFFFF;
            --df-messenger-button-titlebar-color: #005AA2;
            --df-messenger-chat-background-color: #fafafa;
            --df-messenger-font-color: black;
            --df-messenger-send-icon: #005AA2;
            --df-messenger-user-message: #C7CBCD;
            --df-messenger-minimized-chat-close-icon-color: black;
          }
      
        </style>
        <df-messenger df-cx="true" location="northamerica-northeast1" chat-title="HR Benefits Digital Assistant" agent-id="2add7129-bb85-4583-9efc-da63acf6d700" language-code="en"></df-messenger>
        <span id="chatbot-initial-messages" style="display:none">
          <p>Hi, I am the HR Benefits Digital Assistant! Click here to ask me a question.</p>
        </span>        
        <span id="chatbot-inactivity-messages" style="display:none">
          <p>This session has been closed due to inactivity. To restart, please click or tap button below.</p>
          <p>{"type": "chips","options": [{"text": "Let's Get Started", "image": {"src": {"rawUrl": "https://i.ibb.co/9Ggztth/baseline-touch-app-black-24dp.png"}}}]}</p>
        </span>
      `;

      window.addEventListener('dfMessengerLoaded', (event) => {
        const scope = this;

        // Remove previously stored session variables
        this.initializeSessionStorage();

        // Show the DF Messenger minimal view, if on a larger screen (non-mobile), and populate initial messages.
        this.initializeChatView();

          // Apply any custom CSS to the messenger.
        this.applyCustomStyles();

        // Add the custom footer.
        this.addCustomFooter();

        // Add a general handler for received messages.
        this.getDFMessengerElement().addEventListener('df-response-received', (event) => {
          scope.responseReceivedHandler(event);
        });

        // Add an observer for chat window state changes (e.g. open / close).
        this.addWindowStateChangeObserver();

        // Add inactivity timeout monitoring.
        setInterval(this.checkInactivityTimeout, INACTIVITY_TIMEOUT_INTERVAL_MS);

        // Update chat window style on resize events.
        window.addEventListener('resize', () => {
          this.updateChatWindowStyle();
        });

        // Update window state in the next event cycle.
        setTimeout(() => {
          this.updateWindowState();
        }, 1);
      });

      this._bottomPlaceholder.domElement.appendChild(div);

      const gdfScript = document.createElement('script');

      gdfScript.src = 'https://www.gstatic.com/dialogflow-console/fast/messenger-cx/bootstrap.js?v=1';
      
      this._bottomPlaceholder.domElement.appendChild(gdfScript);
    }
  }

  public onInit(): Promise<void> {
    Log.info(LOG_SOURCE, `Initialized ${strings.Title}`);

    this.context.placeholderProvider.changedEvent.add(this, this._renderPlaceHolders);

    return Promise.resolve();
  }
}
