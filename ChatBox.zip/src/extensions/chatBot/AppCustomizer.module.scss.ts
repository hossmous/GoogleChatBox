/* tslint:disable */
require("./AppCustomizer.module.css");
const styles = {
  app: 'app_c7f312e0',
  top: 'top_c7f312e0',
  bottom: 'bottom_c7f312e0'
};

export default styles;
/* tslint:enable */